PROJECT: Import Data using Transform Maps (ServiceNow)
Duration: 28-Sep-2026 to 03-Oct-2026
Team Lead: Niranjana Jayabalan
Team Members: Nancy N, Kanitha Sri, Nivya Sri G

PURPOSE
This project imports employee data from an Excel spreadsheet into ServiceNow
using a Data Source, an Import Set (staging) table, and a Transform Map. The
data is loaded into the Employee Test table (u_employee_test).

FOLDER STRUCTURE
1. Project Initiation        - Abstract, Problem Statement, Objectives, Scope
2. Requirement Analysis      - Functional, Software, Table/Field, User Role requirements
3. Project Design Phase      - Database Table Design, System Architecture, Project Workflow, Field Mapping
4. Project Planning Phase    - Project Plan, Milestones, Timeline, Team Responsibilities
5. Project Development Phase - Data Import Files, Transform Map Files, Implementation Screenshot
6. Project Documentation     - Final Report, Results, Conclusion, ACL Test Checklist, Import & Security document

HOW THE IMPORT WORKS
1. Prepare the Excel file (Employee ID, Name, Email, Department, Location).
2. Create a Data Source and attach the Excel file.
3. Load the data into the Import Set table Employee import (u_employee_import).
4. Create a Transform Map from the Import Set table to Employee Test (Transform Map: Sample Spreadsheet Import).
5. Map the fields and set Employee ID as the coalesce field.
6. Run the Transform Map.
7. Check Import Log and Transform History for errors.
8. Verify the records in the Employee Test list.

NOTES
- Fill in the "____" values in Project_Results.docx from Transform History.
- Fill in the Actual and Pass/Fail columns in ACL_Test_Checklist.docx after testing.
- Store screenshots in the Implementation Screenshot folder with numbered names.
